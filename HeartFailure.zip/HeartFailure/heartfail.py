from tkinter import*
import tkinter as tk
from PIL import Image, ImageTk
from tkinter import PhotoImage

window = tk.Tk()
window.geometry("1000x1000")
window.title("HEART FAILURE PREDICTION")

image = Image.open("heart.jpg")
i1= ImageTk.PhotoImage(image)
label = Label(image=i1).place(x = 0,y = 0)

l1 = tk.Label(text = "AGE",fg = "black")
l1.place(x = 100,y = 50)

l2 = tk.Label(text = "RESTINGBP",fg = "black")
l2.place(x = 100,y = 100)

l3 = tk.Label(text = "CHOLESTEROL",fg = "black")
l3.place(x = 100,y = 150)

l4 = tk.Label(text = "FASTINGBS",fg = "black")
l4.place(x = 100,y = 200)

l5 = tk.Label(text = "MAXHR",fg = "black")
l5.place(x = 100,y = 250)

l6 = tk.Label(text = "OLDPEAK",fg = "black")
l6.place(x = 100,y = 300)

l7 = tk.Label(text = "SEX_F",fg = "black")
l7.place(x = 100,y = 350)

l8 = tk.Label(text = "SEX_M",fg = "black")
l8.place(x = 100,y = 400)

l9 = tk.Label(text = "CHESTPAINTYPE_ASY",fg = "black")
l9.place(x = 100,y = 450)

l10 = tk.Label(text = "CHESTPAINTYPE_ATA",fg = "black")
l10.place(x = 100,y = 500)

l11 = tk.Label(text = "CHESTPAINTYPE_NAP",fg = "black")
l11.place(x = 100,y = 550)

l12 = tk.Label(text = "CHESTPAINTYPE_TA",fg = "black")
l12.place(x = 100,y = 600)

l13 = tk.Label(text = "HEART DISEASE",fg = "black")
l13.place(x = 900,y = 400)


text1 = tk.Entry()
text1.place(x = 500,y = 50)

text2 = tk.Entry()
text2.place(x = 500,y = 100)

text3 = tk.Entry()
text3.place(x = 500,y = 150)

text4 = tk.Entry()
text4.place(x = 500,y = 200)

text5 = tk.Entry()
text5.place(x = 500,y = 250)


text6 = tk.Entry()
text6.place(x = 500,y = 300)

text7 = tk.Entry()
text7.place(x = 500,y = 350)


text8 = tk.Entry()
text8.place(x = 500,y = 400)

text9 = tk.Entry()
text9.place(x = 500,y = 450)

text10 = tk.Entry()
text10.place(x = 500,y = 500)

text11 = tk.Entry()
text11.place(x = 500,y = 550)


text12 = tk.Entry()
text12.place(x = 500,y = 600)

text13 = tk.Entry()
text13.place(x = 1100,y = 400)

text14 = tk.Entry(width = 30)
text14.place(x = 1000,y = 450)


def clear():
    text1.delete(0,END)
    text2.delete(0,END)
    text3.delete(0,END)
    text4.delete(0,END)
    text5.delete(0,END)
    text6.delete(0,END)
    text7.delete(0,END)
    text8.delete(0,END)
    text9.delete(0,END)
    text10.delete(0,END)
    text11.delete(0,END)
    text12.delete(0,END)
    text13.delete(0,END)
    text14.delete(0,END)


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

import warnings
warnings.filterwarnings('ignore')

from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import LabelEncoder

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier

from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report

df = pd.read_csv("D:\\EDA\\HeartFailure\\heart.csv")

df = pd.get_dummies(df, columns=['Sex','ChestPainType','ExerciseAngina'])

x = df[['Age', 'RestingBP', 'Cholesterol', 'FastingBS', 'MaxHR',
       'Oldpeak', 'Sex_F', 'Sex_M',
       'ChestPainType_ASY', 'ChestPainType_ATA', 'ChestPainType_NAP',
       'ChestPainType_TA']]
y = df['HeartDisease']
x_train,x_test,y_train,y_test = train_test_split(x,y,test_size = 0.2,random_state = 1)

dt = DecisionTreeClassifier()
dt.fit(x_train,y_train)
y_pred = dt.predict(x_test)

def predict():
    try:
        new = np.array([float(text1.get()),float(text2.get()),float(text3.get()),float(text4.get()),float(text5.get()),
                        float(text6.get()),float(text7.get()),float(text8.get()),float(text9.get()),float(text10.get()),
                        float(text11.get()),float(text12.get())])
        ans = dt.predict([new])
        final = ans[0]  # Get the first (and only) element of the result
        text13.insert(0, final)


        if ans == 0:
            text14.insert(0,"HEART DISEASE NOT PRESENT")
        else:
            text14.insert(0,"HEART DISEASE PRESENT")

    except ValueError as v:
        print("Invalid Error")

  

accuracy = accuracy_score(y_test,y_pred)
print("accuracy:",accuracy)

button1 = tk.Button(text = 'CLEAR',fg = 'black',command = clear).place(x = 1000,y = 500)
button1 = tk.Button(text = 'PREDICT',fg = 'black',command = predict).place(x = 1000,y = 550)

window.mainloop()

